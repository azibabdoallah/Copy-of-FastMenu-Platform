
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import CustomerMenu from './components/CustomerMenu';
import AdminDashboard from './components/AdminDashboard';
import LandingPage from './components/LandingPage';
import AuthPage from './components/AuthPage';
import SelectionPage from './components/SelectionPage';
import ProtectedRoute from './components/ProtectedRoute';
import PublicRoute from './components/PublicRoute';
import { getRestaurantConfig, saveRestaurantConfig, clearLocalData } from './services/storageService';
import { RestaurantConfig } from './types';
import { DEFAULT_CONFIG } from './constants';
import { supabase } from './services/supabase';
import { Loader2 } from 'lucide-react';

const App: React.FC = () => {
  const [config, setConfig] = useState<RestaurantConfig>(DEFAULT_CONFIG);
  const [loading, setLoading] = useState(true);

  // وظيفة لتطبيق اللون المخصص على صفحة العميل فقط عبر متغير CSS
  const applyCustomerBranding = (color: string) => {
    if (color) {
      document.documentElement.style.setProperty('--customer-brand', color);
    }
  };

  const loadData = async () => {
    setLoading(true);
    try {
        const data = await getRestaurantConfig();
        setConfig(data);
        applyCustomerBranding(data.primaryColor);
    } catch (error) {
        console.error("Failed to load data", error);
    } finally {
        setLoading(false);
    }
  };

  useEffect(() => {
    const initAuth = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        if (error && (error.message.includes('refresh_token_not_found') || error.message.includes('Invalid Refresh Token'))) {
          await supabase.auth.signOut();
          clearLocalData();
          setConfig(DEFAULT_CONFIG);
        }
      } catch (err) {
        console.warn("Auth check failed:", err);
      }
      await loadData();
    };

    initAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
        if (event === 'SIGNED_OUT') {
            clearLocalData();
            setConfig(DEFAULT_CONFIG);
            applyCustomerBranding(DEFAULT_CONFIG.primaryColor);
        } else if (event === 'SIGNED_IN' || event === 'INITIAL_SESSION') {
            loadData();
        }
    });

    return () => {
        subscription.unsubscribe();
    };
  }, []);

  const handleUpdateConfig = async (newConfig: RestaurantConfig) => {
    setConfig(newConfig);
    applyCustomerBranding(newConfig.primaryColor);
    await saveRestaurantConfig(newConfig);
  };

  const handleLogout = async () => {
      clearLocalData();
      setConfig(DEFAULT_CONFIG);
      applyCustomerBranding(DEFAULT_CONFIG.primaryColor);
      await supabase.auth.signOut();
      window.location.hash = '/auth'; 
  };

  if (loading) {
    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50 text-amber-400">
            <div className="flex flex-col items-center gap-2">
                <Loader2 className="animate-spin" size={40} />
                <p>جاري تحميل البيانات...</p>
            </div>
        </div>
    );
  }

  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<PublicRoute><LandingPage /></PublicRoute>} />
        <Route path="/auth" element={<PublicRoute><AuthPage /></PublicRoute>} />
        <Route path="/select" element={<ProtectedRoute><SelectionPage /></ProtectedRoute>} />
        <Route path="/admin" element={<ProtectedRoute><AdminDashboard config={config} onUpdate={handleUpdateConfig} onLogout={handleLogout}/></ProtectedRoute>} />
        
        <Route path="/menu" element={<CustomerMenu config={config} />} />
        <Route path="/menu/:restaurantName" element={<CustomerMenu config={config} />} />
        
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </HashRouter>
  );
};

export default App;
