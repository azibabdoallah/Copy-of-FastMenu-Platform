
import { supabase } from './supabase';
import { Order } from '../types';

const ORDERS_STORAGE_KEY = 'restaurant_orders';

// مفاتيح لتمييز نوع الطلب في قاعدة البيانات دون الحاجة لأعمدة إضافية
const DELIVERY_PREFIX = 'DELIVERY_V1|||';
const DINEIN_PREFIX = 'DINEIN_V1|||';

// --- تنظيف الطلبات القديمة تلقائياً (أقدم من 8 ساعات) ---
const CLEANUP_HOURS = 8;

const cleanupOldOrders = async () => {
  try {
    const cutoffTime = new Date(Date.now() - CLEANUP_HOURS * 60 * 60 * 1000).toISOString();
    
    // 1. حذف من Supabase
    const { error } = await supabase
      .from('orders')
      .delete()
      .lt('created_at', cutoffTime);
    
    if (error) console.error("Supabase cleanup error:", error);

    // 2. تنظيف التخزين المحلي (للحالات غير المتصلة)
    const storedOrders = localStorage.getItem(ORDERS_STORAGE_KEY);
    if (storedOrders) {
      const orders: Order[] = JSON.parse(storedOrders);
      const freshOrders = orders.filter(o => {
          if (!o.created_at) return true; 
          return new Date(o.created_at).getTime() > new Date(cutoffTime).getTime();
      });
      if (freshOrders.length !== orders.length) {
          localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(freshOrders));
      }
    }
  } catch (err) {
    console.warn("Cleanup process failed:", err);
  }
};

export const submitOrder = async (order: Omit<Order, 'id' | 'created_at' | 'status'>) => {
  try {
    let finalTableNumber = order.table_number;

    // تشفير بيانات التوصيل أو الطاولة في حقل table_number لضمان التوافق مع الجداول البسيطة
    if (order.type === 'delivery') {
        const cleanPhone = (order.phone || '').replace(/\|\|\|/g, ' ');
        const cleanAddress = (order.address || '').replace(/\|\|\|/g, ' ');
        finalTableNumber = `${DELIVERY_PREFIX}${cleanPhone}|||${cleanAddress}`;
    } else if (order.type === 'dine_in') {
        const cleanTable = (order.table_number || '').replace(/\|\|\|/g, ' ');
        const cleanCode = (order.verification_code || '').replace(/\|\|\|/g, ' ');
        finalTableNumber = `${DINEIN_PREFIX}${cleanTable}|||${cleanCode}`;
    }

    const submissionData = {
        restaurant_id: order.restaurant_id, // الـ ID الخاص بصاحب المطعم
        customer_name: order.customer_name,
        table_number: finalTableNumber,
        items: order.items, 
        total: order.total,
        status: 'pending'
    };

    const { data, error } = await supabase
      .from('orders')
      .insert([submissionData])
      .select();
  
    if (error) throw error;
    return data;
  } catch (error) {
    console.warn("Order submission failed, saving locally:", error);
    
    const newOrder: Order = {
      ...order,
      id: Date.now(), 
      status: 'pending',
      created_at: new Date().toISOString()
    };
    
    // في المتصفح الخفي، التخزين المحلي لا يصل للمسؤول، لذا نفضل دائماً الـ Supabase
    const storedOrders = localStorage.getItem(ORDERS_STORAGE_KEY);
    const orders: Order[] = storedOrders ? JSON.parse(storedOrders) : [];
    localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify([newOrder, ...orders]));
    return [newOrder];
  }
};

export const getOrders = async () => {
  await cleanupOldOrders();

  try {
    // الحصول على المستخدم الحالي (المسؤول)
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
        console.warn("No authenticated user found for fetching orders.");
        return [];
    }

    // جلب الطلبات المرتبطة بهذا المسؤول فقط (الفلترة هنا هي الحل!)
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .eq('restaurant_id', user.id) // نضمن جلب طلبات مطعمك فقط
      .order('created_at', { ascending: false });
      
    if (error) throw error;

    // إعادة معالجة البيانات المستخرجة من الحقل المدمج
    const formattedData = (data as any[]).map(order => {
        const tNum = order.table_number;
        if (tNum && typeof tNum === 'string') {
            if (tNum.startsWith(DELIVERY_PREFIX)) {
                const parts = tNum.split('|||');
                return {
                    ...order,
                    type: 'delivery',
                    phone: parts[1] || '',
                    address: parts[2] || '',
                    table_number: 'توصيل'
                };
            } else if (tNum.startsWith(DINEIN_PREFIX)) {
                const parts = tNum.split('|||');
                return {
                    ...order,
                    type: 'dine_in',
                    table_number: parts[1] || '?',
                    verification_code: parts[2] || ''
                };
            }
        }
        return { ...order, type: 'dine_in' };
    });

    return formattedData as Order[];
  } catch (error) {
    console.warn("Fetching orders failed, falling back to local:", error);
    const storedOrders = localStorage.getItem(ORDERS_STORAGE_KEY);
    return storedOrders ? JSON.parse(storedOrders) : [];
  }
};

export const updateOrderStatus = async (id: number, status: string) => {
  try {
    const { error } = await supabase
      .from('orders')
      .update({ status })
      .eq('id', id);

    if (error) throw error;
  } catch (error) {
    console.warn("Updating status failed:", error);
    const storedOrders = localStorage.getItem(ORDERS_STORAGE_KEY);
    if (storedOrders) {
      const orders: Order[] = JSON.parse(storedOrders);
      const updatedOrders = orders.map(o => o.id === id ? { ...o, status: status as any } : o);
      localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(updatedOrders));
    }
  }
};
